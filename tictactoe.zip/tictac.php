<?php
session_start();
require_once("tictactoe.php");
use Feng\Tictactoe\Tictactoe;
require_once("response.php");//include KooKoo library
$r=new Response(); //create a response object
$cd = new CollectDtmf();
/*
if(isset($_SESSION['game']))
	echo "game set";
else
	echo "not set";
*/

function convert( $c )
{
	if($c==1) { $x=0;$y=0; } elseif($c==2) { $x=1;$y=0; } elseif($c==3) { $x=2;$y=0; } elseif($c==4) { $x=0;$y=1; } elseif($c==5) { $x=1;$y=1; } elseif($c==6) { $x=2;$y=1; } elseif($c==7) { $x=0;$y=2; } elseif($c==8) { $x=1;$y=2; } elseif($c==9) { $x=2;$y=2; } else{ $x=-1;$y=-1;}
		return array( $x, $y );
}
function convertBack( $x,$y )
{
	if($x==0 && $y==0) return 1; elseif($x==1 && $y==0) return 2; elseif($x==2 && $y==0) return 3; elseif($x==0 && $y==1) return 4; elseif($x==1 && $y==1) return 5; elseif($x==2 && $y==1) return 6; elseif($x==0 && $y==2) return 7; elseif($x==1 && $y==2) return 8; elseif($x==2 && $y==2) return 9;
}
function sendMsg($no,$msg)
{
	$postdata = "name=TicTacIVR&no=".$no."&msg=".$msg;
			$ch = curl_init(); 
			curl_setopt($ch, CURLOPT_URL,'http://faltusms.tk/sendSms.php');  
			curl_setopt ($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6"); 			
			curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
			curl_setopt($ch, CURLOPT_VERBOSE, 1); 
			curl_setopt ($ch, CURLOPT_TIMEOUT, 60); 
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);   
			curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata); 
			curl_setopt ($ch, CURLOPT_POST, 1);		   
			$result = curl_exec($ch);
}
if (isset($_REQUEST['event']) && $_REQUEST['event']=="NewCall")   
{
	$game = new Tictactoe(); // Create a new game
	
        $r->addPlayText("Let's start the game. Numbers from 1 to 9 represent the 3 cross 3 board. ",$speed=3);
        $x = rand(0,1);
		if($x==0)
		{
			$r->addPlayText(" computer's chance first ",$speed=3);
			$a=$game->getBestMove( $game::PLAYER_A );
			$game->playTile( $game::PLAYER_A, $a[0], $a[1] );
			$move=convertBack( $a[0], $a[1] );
			$r->addPlayText(" computer crossed ".$move." , your turn now ",$speed=3);
			$_SESSION['game']=serialize($game);
		}
		else
		{
			$r->addPlayText(" your chance first ",$speed=3);
			$_SESSION['game']=serialize($game);
		}
        $r->addCollectDtmf($cd);
        $r->send();
}             
elseif (isset($_REQUEST['event']) && $_REQUEST['event']=="GotDTMF") 
{
		$game=unserialize($_SESSION['game']);
        $choice=$_REQUEST['data'];
		$no=$_REQUEST['cid'];
		$a=convert($choice);
		if($a[0] == -1 || !$game->isAvailable( $a[0],$a[1] ))
		{
			$r->addPlayText(" Invalid Move . Try again ",$speed=4);
			$_SESSION['game']=serialize($game);
			$r->addCollectDtmf($cd);
			$r->send();
		}
		$check=$game->playTile( $game::PLAYER_B, $a[0], $a[1] );
		if(!$check)
		{
			if($game->isEnded())
			{	
				if($game->getWinner() == 2)
				{
					$r->addPlayText(" you WIN . Congrats . ",$speed=3);
					sendMsg($no,"Congrats !! Call 08030178427 to keep playing.");
					$r->addHangup();
					$r->send();
					exit();
				}
				elseif($game->getWinner() == 1)
					{
						$r->addPlayText(" You Lost . better luck next time ",$speed=3);
					sendMsg($no,"Hard luck !! Call 08030178427 to try again.");
						$r->addHangup();
						$r->send();
						exit();
					}
				else
				{
					$c=0;
					for($i=0;$i<3;$i++)
					{
						for($j=0;$j<3;$j++)
						{
							if(!$game->isAvailable( $i, $j ))
								$c++;
						}
					}
					if($c==9)
					{
						$r->addPlayText(" Game drawn ",$speed=3);
						sendMsg($no,"Well tried !! Call 08030178427 to keep playing.");
					}
					
					$r->addHangup();
					$r->send();
					exit();
				}
			}
		}
		else
		{
			
		$r->addPlayText(" you crossed ".$choice,$speed=3);
			$a=$game->getBestMove( $game::PLAYER_A );
			$check=$game->playTile( $game::PLAYER_A, $a[0], $a[1] );
			$move=convertBack( $a[0], $a[1] );
			if($check)
			{
				$r->addPlayText("  Now computer crossed ".$move,$speed=3);
				$r->addPlayText(" your turn  ",$speed=3);
			}
			
				if($game->isEnded())
			{	
				if($game->getWinner() == 2)
				{
					$r->addPlayText(" you WIN . Congrats . ",$speed=3);
					sendMsg($no,"Congrats !! Call 08030178427 to keep playing.");
					$r->addHangup();
					$r->send();
					exit();
				}
				elseif($game->getWinner() == 1)
					{
						$r->addPlayText(" You Lost . better luck next time ",$speed=3);
					sendMsg($no,"Hard luck !! Call 08030178427 to try again.");
						$r->addHangup();
						$r->send();
						exit();
					}
				else
				{
					$c=0;
					for($i=0;$i<3;$i++)
					{
						for($j=0;$j<3;$j++)
						{
							if(!$game->isAvailable( $i, $j ))
								$c++;
						}
					}
					if($c==9)
					{
						$r->addPlayText(" Game drawn ",$speed=3);
						sendMsg($no,"Well tried !! Call 08030178427 to keep playing.");
					}
					
					$r->addHangup();
					$r->send();
					exit();
				}
			}
			
			$_SESSION['game']=serialize($game);
			$r->addCollectDtmf($cd);
			$r->send();
		}
}
else
{
    $r->addPlayText("Thank you for playing ");
    $r->addHangup();
    $r->send();
    exit();
}
?>