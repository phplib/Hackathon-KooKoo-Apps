Name: Yash Trivedi
Contact: +91 8110020583
Associated Number: 918030178427

About - 

This is a tic tac game played between the user and the computer. 
The game is played as a 3x3 table and the numbers 1 to 9 on the keypad represent the individual cells.
The first player is decided randomly and then the game proceeds with the user and the computer making moves alternatively until a player loses or the game is drawn.
The moves made by the computer are decided using an AI based library in order to make the best move at each stage.
Result of the game is communicated to the user using SMS (sent using twilio API).