<?php
	echo "Welcome to the Dragon Ball Z Arena."
?>
