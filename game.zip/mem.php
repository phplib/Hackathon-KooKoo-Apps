<?php
require_once("response.php");//include KooKoo library
$r=new Response(); //create a response object
$cd = new CollectDtmf();
if ( $_SESSION['event'] == "NewCall" )   
{
	$_SESSION['event']="Call";
        $_SESSION['level']=1;$n=6;$_SESSION['n']=$n;
        $r->addPlayText("Your task is to repeat the following numbers in the same sequence.");
		$r->addPlayText("Level ".$_SESSION['level']." ");
		$numbers = range(0, $n-1);
		shuffle($numbers);
		for($i=0;$i<$_SESSION['n'];$i++)
		{
			$r->addPlayText($numbers[$i]);
		}
		$_SESSION['ans']=implode("",$numbers);
		$r->addPlayText("Enter the sequence ");
        $r->addCollectDtmf($cd);
        $r->send();
}             
elseif (isset($_REQUEST['event']) && $_REQUEST['event']=="GotDTMF") 
{
        $ans=$_REQUEST['data'];
		$no=$_REQUEST['cid'];
		if( $ans == $_SESSION['ans'] )
		{
			$_SESSION['level']++;
            $r->addPlayText("Correct. Level ".$_SESSION['level']." ");
			$_SESSION['n']=$_SESSION['n']+2;
            $numbers = range(0, $_SESSION['n']-1);
			shuffle($numbers);
			for($i=0;$i<$_SESSION['n'];$i++)
			{
				$r->addPlayText($numbers[$i]);
			}
			$_SESSION['ans']=implode("",$numbers);
			$r->addPlayText("Enter the sequence ");
			$r->addCollectDtmf($cd);
			$r->send();
        }
        else
		{
			$r->addPlayText("Sorry. Your answer was wrong. Thanks for playing");
			$r->addHangup();
			$r->send();
			exit();
		}
}
else
{
    $r->addPlayText("Thank you for playing ");
    $r->addHangup();
    $r->send();
    exit();
}
?>
