Name: Anuj Shankar
Contact: +91 9943131491
Associated Number: 914433012840


About-

It is a menu based application consisting of three games-

1. GUESS THE NUMBER - 

A random number is generated between 1 to 20 and the user gets 3 chances to successfully guess the number. 
The user wins if he/she is able to guess the number correctly within 3 chances, otherwise he/she loses the game.

2. MEMORY GAME - 

A string of numbers between 0 to 9 is generated and the user needs to repeat the numbers in the same order to proceed to the next level.
The difficulty level of the game increases with each successive level.

3. MENTAL MATHS -

A mathematical expression is played to the user and the user needs to evaluate it and enter the correct answer to proceed to the next level.
The difficulty level of the game increases with each successive level.

