<?php
require_once("response.php");//include KooKoo library
$r=new Response(); //create a response object
$cd = new CollectDtmf();
if ( $_SESSION['event'] == "NewCall" )   
{
		$_SESSION['event']="Call";
        $_SESSION['level']=1;$n=3;$_SESSION['n']=$n;
        $r->addPlayText("Your task is to evaluate the following sequence.");
		$r->addPlayText("Level ".$_SESSION['level']." ");
		$numbers = range(1, $n);
		shuffle($numbers);
		$_SESSION['ans']=$numbers[0];
		$r->addPlayText($numbers[0]);
		for($i=1;$i<$_SESSION['n'];$i++)
		{
			$op=rand(1,4);
			if($op==1)
			{
				$r->addPlayText(" plus  ");
				$_SESSION['ans']=$_SESSION['ans']+$numbers[$i];				
			}
			elseif($op==2)
			{
				$r->addPlayText(" minus  ");
				$_SESSION['ans']=$_SESSION['ans']-$numbers[$i];				
			}
			elseif($op==3)
			{
				$r->addPlayText(" multiplied by  ");
				$_SESSION['ans']=$_SESSION['ans']*$numbers[$i];				
			}
			elseif($op==4)
			{
				$r->addPlayText(" divided by  ");
				$_SESSION['ans']=($_SESSION['ans'])/$numbers[$i];				
			}
			$r->addPlayText($numbers[$i]);
		}
		$r->addPlayText(" Enter the positive integer  part of the answer ");
        $r->addCollectDtmf($cd);
        $r->send();
}             
elseif (isset($_REQUEST['event']) && $_REQUEST['event']=="GotDTMF") 
{
        $ans=$_REQUEST['data'];
		$no=$_REQUEST['cid'];
		if($_SESSION['ans']<0)
			$_SESSION['ans']=-1*$_SESSION['ans'];
		if( $ans == floor($_SESSION['ans'] ))
		{
			$_SESSION['level']++;
            $r->addPlayText("Correct. Level ".$_SESSION['level']." ");
			$_SESSION['n']=$_SESSION['n']+2;
			$numbers = range(1, $_SESSION['n']);
			shuffle($numbers);
            $_SESSION['ans']=$numbers[0];
			$r->addPlayText($numbers[0]);
			for($i=1;$i<$_SESSION['n'];$i++)
			{
				$op=rand(1,4);
				if($op==1)
				{
					$r->addPlayText(" plus  ");
					$_SESSION['ans']=$_SESSION['ans']+$numbers[$i];				
				}
				elseif($op==2)
				{
					$r->addPlayText(" minus  ");
					$_SESSION['ans']=$_SESSION['ans']-$numbers[$i];				
				}
				elseif($op==3)
				{
					$r->addPlayText(" multiplied by  ");
					$_SESSION['ans']=$_SESSION['ans']*$numbers[$i];				
				}
				elseif($op==4)
				{
					$r->addPlayText(" divided by  ");
					$_SESSION['ans']=$_SESSION['ans']/$numbers[$i];				
				}
				$r->addPlayText($numbers[$i]);
			}
			$r->addPlayText("Enter the positive integer  part of the answer ");
				$r->addCollectDtmf($cd);
				$r->send();
		}
        else
		{
			$r->addPlayText("Sorry. Your answer was wrong. Thanks for playing");
			$r->addHangup();
			$r->send();
			exit();
		}
}
else
{
    $r->addPlayText("Thank you for playing ");
    $r->addHangup();
    $r->send();
    exit();
}
?>
