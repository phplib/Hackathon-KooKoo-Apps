<?php
session_start();
require_once("response.php");//include KooKoo library
$r=new Response(); //create a response object
$cd = new CollectDtmf();

if (isset($_REQUEST['event']) && $_REQUEST['event'] == 'NewCall')   
{
		$r->addPlayText(" Welcome to the Arena. Press 1 to play guess the Number , 2 to play memory magic , 3 to play mental maths ");
		$r->addPlayText(" Enter your choice " );
        $r->addCollectDtmf($cd);
        $r->send();
}             
elseif (isset($_REQUEST['event']) && $_REQUEST['event']=="GotDTMF") 
{
        $choice=$_REQUEST['data'];
		
		if($choice==1)
		{
			$_SESSION['event']="NewCall";
			$r->addGoto("http://kookoo-ecomm.azurewebsites.net/game/guess.php");
			$r->send();
		}
		elseif($choice==2)
		{
			$_SESSION['event']="NewCall";
			$r->addGoto("http://kookoo-ecomm.azurewebsites.net/game/mem.php");
			$r->send();
		}
		elseif($choice==3)
		{
			$_SESSION['event']="NewCall";
			$r->addGoto("http://kookoo-ecomm.azurewebsites.net/game/math.php");
			$r->send();
		}
        else
		{
			$r->addPlayText("Wrong option selected ");
			$r->addPlayText("  Press 1 to play guess the Number , 2 to play memory magic , 3 to play mental maths ");
			$r->addPlayText(" Enter your choice " );
			$r->addCollectDtmf($cd);
			$r->send();
			exit();
		}
}
else
{
    $r->addPlayText("Thank you for playing ");
    $r->addHangup();
    $r->send();
    exit();
}
?>
