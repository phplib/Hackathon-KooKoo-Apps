KooKoo Game hack Challenge Submission

Name: Aakash Malhotra
Contact: +918110020614

Website: http://quizkoo.azurewebsites.net
Associated Number: +91 44 33012998

----------------------------------------------------------------------------------------------------------------------------------------
NOTE: Please register at http://quizkoo.azurewebsites.net before using this service.
----------------------------------------------------------------------------------------------------------------------------------------

INSTRUCTIONS:

1. Register at http://quizkoo.azurewebsites.net before using.
2. Add friends and view all scores from your dashboard.
3. Call +914433012998 to take a new quiz.

FEATURES: 

1. Answer the quiz anytime from anyplace.
2. View your friends scores on your dashboard.
3. View your own scores and monitor your progress.
4. Since it does not depend on the type of phone used or internet connection, it can be used anytime from any place.
5. Score Updates through SMS.

----------------------------------------------------------------------------------------------------------------------------------------
NOTE: SMS alerts available only for verified numbers,due to twilio trial account restrictions. (see screenshots )
----------------------------------------------------------------------------------------------------------------------------------------







