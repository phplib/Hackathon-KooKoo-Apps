<?php
include("php/db.php");
session_start();
require_once("response.php");//include KooKoo library
$r=new Response(); //create a response object
$cd = new CollectDtmf();
if (isset($_REQUEST['event']) && $_REQUEST['event'] == 'NewCall')   
{
        $no=$_REQUEST['cid'];
        $result = mysqli_query($conn,"select * from user where  mobile='$no' ");
        $row_cnt = $result->num_rows;
        $row = mysqli_fetch_assoc($result);
        $userid=$row['id']; 
   /*     if ($row_cnt==0)    //check if user registered
        {
             $r->addPlayText("Sorry. This number is not registered. Thank you for calling, have a nice day");
			 $postdata = "name=KooKoo Idol&no=".$no."&msg=register at  ";
			$ch = curl_init(); 

			curl_setopt($ch, CURLOPT_URL,'http://faltusms.tk/sendSms.php');  
			curl_setopt ($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6"); 			
			curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
			curl_setopt($ch, CURLOPT_VERBOSE, 1); 
			curl_setopt ($ch, CURLOPT_TIMEOUT, 60); 
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);   
			curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata); 
			curl_setopt ($ch, CURLOPT_POST, 1);		   
			$result = curl_exec($ch);
             $r->addHangup();
             $r->send();
             exit();
        }
		*/
		if($row_cnt==0)
		{$_SESSION['reg']=0;}
		else
		{$_SESSION['reg']=1;}		
		$_SESSION['id']=$userid;
		$_SESSION['mode']="choice";
    $r->addPlayText("Press 1 to record your song , 2 to vote for others ");
    $r->addCollectDtmf($cd);
}
elseif (isset($_REQUEST['event']) && $_REQUEST['event'] == 'GotDTMF' ) //input taken from user
{
	$no=$_REQUEST['cid'];
    $choice=$_REQUEST['data'];
	$userid=$_SESSION['id'];
		if($_SESSION['mode']=="choice" && $choice==1)
		{
			if($_SESSION['reg']!=0)
			{
				$_SESSION['mode']="record";
				$r->addPlayText(" record your song after the beep ");
				$r->addRecord($userid."_".md5(time()));//record audio 	
			}	
			else
			{
				 $r->addPlayText("Sorry. This number is not registered. Thank you for calling, have a nice day");
			}		
		}
		elseif($_SESSION['mode']=="choice" && $choice==2)
		{
			$arr = array();
			$result = mysqli_query($conn,"SELECT * FROM audio WHERE mobile != $no");
			 
			$row_cnt = $result->num_rows;
			if ($row_cnt==0)  
			{
				 $r->addPlayText("Sorry. There are no new songs to play right now ");
			}
			$i=1;
			while ($q = mysqli_fetch_assoc($result))
			{
				$arr[] = $q['id'];
							$r->addPlayText(" ".$i." ");
							$r->addPlayAudio($q['url']);
							$i++;		
			}
			$_SESSION['list']=$arr;
			if($row_cnt>0)
			{
				$r->addPlayText("Enter the number of the song you wish to vote for ");
				$_SESSION['mode']="vote";
				$r->addCollectDtmf($cd);	
			}
		}
		elseif($_SESSION['mode']=="choice" && $choice>2)
		{
			$r->addPlayText("Press 1 to record your song , 2 to vote for others ");
			$r->addCollectDtmf($cd);
		}
		elseif($_SESSION['mode']=="vote")
		{
			$a = $_SESSION['list'];$k=$choice-1;
			if($k<count($a))
			{
				$res = mysqli_query($conn,"UPDATE audio SET vote=vote+1 WHERE id = $a[$k]");
				$r->addPlayText("Your vote has been recorded successfully. thanks for voting");
			}
			else
			{$r->addPlayText("Incorrect input. ");}
		}
}
elseif (isset($_REQUEST['event']) && $_REQUEST['event'] == 'Record') //recording completed
{
        $url=$_REQUEST['data'];
		$no=$_REQUEST['cid'];
		$v=0;
        $result = mysqli_query($conn,"INSERT INTO audio (url,mobile,vote) VALUES ('$url',$no,$v)"); //save recording url
        $r->addPlayText("your song has been recorded successfully. ");
}
else
{
    $r->addPlayText("Thank you for calling kookoo idol ");
    $r->addHangup(); //end call
}
$r->send();
?>
