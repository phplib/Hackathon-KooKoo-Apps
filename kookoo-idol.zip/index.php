<?php
	include 'php/db.php';
?>

<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Kookoo Idol</title>
	<script src="jquery-1.8.3.min.js"></script>

    <script>

	function vote( aid ) {
		
		$.post("vote.php", { id: aid }, function( data ) {			
		location.reload(true);
		}); 
	}
	
	</script>

		<style>
			
			html {
			  height: 100%;
			}
			body {
				background: -webkit-radial-gradient(top left, ellipse cover, rgba(105,155,200,1) 0%,rgba(181,197,216,1) 57%);
				color:white;
			}
			a{
				color:white;
			}
			img{
				padding-left:20px;
				height:30px;width:30px;
			}
			.list{
				padding-left:100px;
				padding-top:50px;
			}
	button.demo {
  background-color: hsl(200,80%,40%);
	border: 1px solid hsl(200,80%,30%);
}
button.signup {
  background-color: hsl(0,80%,40%);
	border: 1px solid hsl(0,80%,30%);
  animation-delay: .3s;
}

button {
  margin-left:800px;
  margin-bottom:10px;
	width: 200px;
  height: 40px;
  border-radius: 20px;
	color: white;
  font-size: 15px;
  font-weight: bold;
  background-image: linear-gradient(top, hsla(0,0%,100%,.2) 1px, hsla(0,0%,100%, 0) 1px, hsla(0,0%,0%, .1) 100% );
  box-shadow: 0 60px 12px -18px hsla(0,0%,0%,.1),
    					0 60px 20px -12px hsla(0,0%,0%,.1);
  animation: float 1s infinite ease-in-out alternate;
}

@keyframes float {
	100% {
    transform: translateY(20px);
    box-shadow: 0 40px 10px -18px hsla(0,0%,0%,.2),
    					0 40px 16px -12px hsla(0,0%,0%,.2);
  }
}
		</style>
    
    
    
  </head>

  <body>

	<div class="content-safe">
      <h1 class="main-headline" align="center">Vote for your favourite contestant here</h1>
	  </div>
    
		
		<div class="list">
				<?php
				   $res = mysqli_query($conn,"SELECT * from audio");
				   $cnt = $res->num_rows;
					if ($cnt==0) 
					{
						 echo "<h2>No new songs.</h2>";
					}
				   while( $row = mysqli_fetch_assoc($res) ) {
					   
					 $q = mysqli_query($conn, "SELECT * FROM user WHERE mobile = ".$row['mobile']);
					 $n = mysqli_fetch_assoc($q);
					 echo "<h3>From - ".$n['name']." at ".$row['timestamp']."</h3>";
					 echo "<audio controls>
						  <source src=".$row['url']." type=audio/mpeg>
						</audio><img onclick = 'vote( ".$row['id']." );' src='icon.png' title='vote'/>";
				   }
				?>
		</div>
		
<a href="score.php" target="_blank"><button class="demo">VIEW LEADERBOARD</button></a>
<a href="register.html" target="_blank"><button class="signup">SIGNUP</button></a>
		
</body>
    

    

</html>
