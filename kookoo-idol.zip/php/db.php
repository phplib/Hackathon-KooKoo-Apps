<?php

	$servername = "us-cdbr-azure-northcentral-b.cloudapp.net:3306";
    $username = "b7255252087975";
    $password = "9e874a38";
     
    $conn = mysqli_connect($servername, $username, $password,'kookoo');
	
	if( !$conn ) {
		die("Unable to connect to db.");
	}
?>
