<?php
	include("php/db.php");
	$audioid = $_POST['id'];
	$res = mysqli_query($conn,"UPDATE audio SET vote=vote+1 WHERE id = $audioid");
?>
